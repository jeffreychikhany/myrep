// DB layer: MySQL connection
const mysql = require('mysql2');

const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'Clapped@123chiks',          // <-- your MySQL password
  database: 'logindb'
});

db.connect(err => {
  if (err) throw err;
  console.log('Connected to MySQL');
});

module.exports = db;