// API layer (Express)
const express = require('express');
const path = require('path');
const db = require('./db');   // connection comes from db.js

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public'))); // UI layer

// POST /api/login  { name, password }
app.post('/api/login', (req, res) => {
  const { name, password } = req.body;
  db.query(
    'SELECT id FROM users WHERE name = ? AND password = ?',
    [name, password],
    (err, rows) => {
      if (err) return res.status(500).json({ success: false, message: 'Server error' });
      if (rows.length > 0) {
        res.json({ success: true, message: 'Successfully logged in' });
      } else {
        res.json({ success: false, message: 'wrong username or password' });
      }
    }
  );
});

app.listen(1337, () => console.log('Server running on http://localhost:1337'));